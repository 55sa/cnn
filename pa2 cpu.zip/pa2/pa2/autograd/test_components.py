#!/usr/bin/env python3
"""
简单测试脚本，验证各个组件的实现
"""
import numpy as np
import sys
import os

# 添加路径以便导入模块
sys.path.append(os.path.dirname(__file__))

from nn.layers.flatten import Flatten
from nn.layers.maxpool2d import MaxPool2d
from nn.layers.conv2d import Conv2d
from nn.layers.dense import Dense
from nn.layers.softmax import Softmax
from nn.layers.relu import ReLU
from nn.losses.cross_entropy import CategoricalCrossEntropy

def test_flatten():
    """测试Flatten层"""
    print("测试Flatten层...")
    flatten = Flatten()
    
    # 创建测试数据: (2, 3, 4, 2)
    X = np.random.randn(2, 3, 4, 2)
    print(f"输入形状: {X.shape}")
    
    # 前向传播
    Y = flatten.forward(X)
    print(f"输出形状: {Y.shape}")
    
    # 反向传播
    dLoss_dY = np.random.randn(*Y.shape)
    dLoss_dX = flatten.backward(X, dLoss_dY)
    print(f"梯度形状: {dLoss_dX.shape}")
    
    assert Y.shape == (2, 24)  # 2 * 3 * 4 * 2 = 24
    assert dLoss_dX.shape == X.shape
    print("✓ Flatten层测试通过\n")

def test_maxpool2d():
    """测试MaxPool2d层"""
    print("测试MaxPool2d层...")
    maxpool = MaxPool2d(pool_size=(2, 2), stride=2)
    
    # 创建测试数据: (2, 4, 4, 3)
    X = np.random.randn(2, 4, 4, 3)
    print(f"输入形状: {X.shape}")
    
    # 前向传播
    Y = maxpool.forward(X)
    print(f"输出形状: {Y.shape}")
    
    # 反向传播
    dLoss_dY = np.random.randn(*Y.shape)
    dLoss_dX = maxpool.backward(X, dLoss_dY)
    print(f"梯度形状: {dLoss_dX.shape}")
    
    assert Y.shape == (2, 2, 2, 3)  # (4-2)//2 + 1 = 2
    assert dLoss_dX.shape == X.shape
    print("✓ MaxPool2d层测试通过\n")

def test_conv2d():
    """测试Conv2d层"""
    print("测试Conv2d层...")
    conv = Conv2d(num_kernels=4, num_channels=3, kernel_size=3, stride=1, padding="valid")
    
    # 创建测试数据: (2, 5, 5, 3)
    X = np.random.randn(2, 5, 5, 3)
    print(f"输入形状: {X.shape}")
    
    # 前向传播
    Y = conv.forward(X)
    print(f"输出形状: {Y.shape}")
    
    # 反向传播
    dLoss_dY = np.random.randn(*Y.shape)
    dLoss_dX = conv.backward(X, dLoss_dY)
    print(f"梯度形状: {dLoss_dX.shape}")
    
    assert Y.shape == (2, 3, 3, 4)  # (5-3)//1 + 1 = 3
    assert dLoss_dX.shape == X.shape
    print("✓ Conv2d层测试通过\n")

def test_dense():
    """测试Dense层"""
    print("测试Dense层...")
    dense = Dense(in_dim=10, out_dim=5)
    
    # 创建测试数据: (3, 10)
    X = np.random.randn(3, 10)
    print(f"输入形状: {X.shape}")
    
    # 前向传播
    Y = dense.forward(X)
    print(f"输出形状: {Y.shape}")
    
    # 反向传播
    dLoss_dY = np.random.randn(*Y.shape)
    dLoss_dX = dense.backward(X, dLoss_dY)
    print(f"梯度形状: {dLoss_dX.shape}")
    
    assert Y.shape == (3, 5)
    assert dLoss_dX.shape == X.shape
    print("✓ Dense层测试通过\n")

def test_softmax():
    """测试Softmax层"""
    print("测试Softmax层...")
    softmax = Softmax()
    
    # 创建测试数据: (3, 4)
    X = np.random.randn(3, 4)
    print(f"输入形状: {X.shape}")
    
    # 前向传播
    Y = softmax.forward(X)
    print(f"输出形状: {Y.shape}")
    print(f"输出和: {np.sum(Y, axis=1)}")  # 应该接近1
    
    # 反向传播
    dLoss_dY = np.random.randn(*Y.shape)
    dLoss_dX = softmax.backward(X, dLoss_dY)
    print(f"梯度形状: {dLoss_dX.shape}")
    
    assert Y.shape == (3, 4)
    assert dLoss_dX.shape == X.shape
    assert np.allclose(np.sum(Y, axis=1), 1.0, atol=1e-6)
    print("✓ Softmax层测试通过\n")

def test_cross_entropy():
    """测试CategoricalCrossEntropy损失函数"""
    print("测试CategoricalCrossEntropy损失函数...")
    loss_func = CategoricalCrossEntropy()
    
    # 创建测试数据
    Y_hat = np.array([[0.7, 0.2, 0.1], [0.1, 0.8, 0.1], [0.3, 0.3, 0.4]])
    Y_gt = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
    
    print(f"预测形状: {Y_hat.shape}")
    print(f"真实标签形状: {Y_gt.shape}")
    
    # 前向传播
    loss = loss_func.forward(Y_hat, Y_gt)
    print(f"损失值: {loss}")
    
    # 反向传播
    grad = loss_func.backward(Y_hat, Y_gt)
    print(f"梯度形状: {grad.shape}")
    
    assert grad.shape == Y_hat.shape
    assert isinstance(loss, float)
    print("✓ CategoricalCrossEntropy测试通过\n")

def main():
    """运行所有测试"""
    print("开始测试CNN组件...\n")
    
    try:
        test_flatten()
        test_maxpool2d()
        test_conv2d()
        test_dense()
        test_softmax()
        test_cross_entropy()
        
        print("🎉 所有测试都通过了！")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
